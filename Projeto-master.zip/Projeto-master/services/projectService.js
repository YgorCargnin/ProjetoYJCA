var fs = require ('fs');

var projectFilePath = 'db/projects.json';

var loadFileProjects = function(){
  var fileData = fs.readFileSync(projectFilePath,'utf8');
  var projects = JSON.parse (fileData);

  return projects;
}

var saveFileprojects = function(projects) {
  var data =JSON.stringify(projects);
  fs.writeFileSync(projectFilePath, data, 'utf8');
}

var getProjects = function() {
var projects = loadFileProjects(); 
  return projects;
}
var saveProjects = function(newProjects) {
  var projects = loadFileProjects();
  projects.push(newProject);
  saveFileprojects(projects);
}
module.exports = {
  getProjects: getProjects,
  saveProjects: saveProjects
}