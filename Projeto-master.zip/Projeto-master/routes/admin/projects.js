var express = require ('express');
var router = express.Router ();
var projectsService = require ('../../services/projectService');

router.get('/', function(req, res, next) {
  var projects = projectsService.getProjects();

  var data = {
    projects: projects
  }

  res.render('admin/projects/index', data);
});

router.get('/create', function(req, res, next){

  res.render('admin/projects/create');

})

module.exports = router;

